#!/bin/bash

clear
neofetch
echo -e "Mod by SL"